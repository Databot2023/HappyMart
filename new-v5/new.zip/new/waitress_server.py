from waitress import serve
from wsgi import application
import os
from dotenv import load_dotenv

# Load settings from .env
load_dotenv()

if __name__ == '__main__':
    # Use settings from .env or defaults.
    host = os.getenv('HOST', '0.0.0.0').strip() or '0.0.0.0'
    port = int(os.getenv('PORT', '8080'))
    threads = int(os.getenv('WAITRESS_THREADS', '4'))
    
    print(f" * Starting Production Waitress server on http://{host}:{port}")
    print(" * Ready for production use.")
    print(" * Press CTRL+C to stop.")
    
    serve(application, host=host, port=port, threads=threads)
