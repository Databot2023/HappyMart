# ComplaintDesk — Setup Guide

## 1. Install Dependencies
```bash
pip install -r requirements.txt
```

## 2. Configuration
Create / edit the `.env` file:
```env
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "test123"
SECRET_KEY     = "your-secret-key"

# PostgreSQL + TimescaleDB (for Old Logs archiving)
TIMESCALE_URL = "postgresql://postgres:yourpassword@localhost:5432/complaint_logs"
```

## 3. PostgreSQL + TimescaleDB Setup (one-time)
```bash
# 1. Create the database in psql
psql -U postgres -c "CREATE DATABASE complaint_logs;"

# 2. Run the setup script (creates table, hypertable, indexes, compression)
psql -U postgres -d complaint_logs -f setup_timescaledb.sql
```

## 4. Run
```bash
python app.py
```
Open: **http://localhost:5050**

### Windows auto-start for PostgreSQL
- On Windows, app startup now attempts to start a PostgreSQL service automatically before TimescaleDB schema initialization.
- Default service detection tries common names such as `postgresql-x64-17`, `postgresql-x64-16`, `postgresql-x64-15`, and `postgresql`.
- If your service has a custom name, set this in `.env`:
```env
POSTGRES_SERVICE_NAME = "postgresql-x64-16"
```
- If service start requires elevated rights, run the terminal as Administrator or start the service manually once.

## Default Credentials (if not using .env)
| Role  | Username | Password |
|-------|----------|----------|
| Admin | admin    | admin    |
| User  | user1    | pass1    |

## Old Logs (TimescaleDB)
- Complaints are **automatically archived** to TimescaleDB when a user marks them complete.
- Browse archived logs at **Admin Dashboard → Old Logs** (`/admin/old-logs`).
- Filters: date range, place, finisher name, keyword search.
- If TimescaleDB is unavailable the app still works normally — the Old Logs page shows an offline banner.

## Ubuntu current project folder
# start server
bash start.sh
# for stop
pkill -f waitress_server


# if host and port change in 
.env file


