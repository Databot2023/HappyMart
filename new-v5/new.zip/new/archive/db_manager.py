import os
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv

# Load database URL from .env
load_dotenv()
URL = os.getenv('TIMESCALE_URL')

def get_conn():
    if not URL:
        print("Error: TIMESCALE_URL not found in .env")
        return None
    return psycopg2.connect(URL, cursor_factory=RealDictCursor)

def show_data():
    conn = get_conn()
    if not conn: return
    with conn.cursor() as cur:
        cur.execute("SELECT * FROM complaint_log ORDER BY created_at DESC")
        rows = cur.fetchall()
        if not rows:
            print("\n--- No data found in complaint_log ---")
        else:
            print(f"\n--- Showing {len(rows)} records ---")
            print("-" * 50)
            for r in rows:
                print(f"ID: {r['complaint_id']} | Place: {r['place']} | Date: {r['completion_date']}")
                print(f"Note: {r['complaint_note']}")
                print("-" * 50)
    conn.close()

def delete_all():
    confirm = input("\n⚠️ Are you SURE you want to delete ALL logs? (yes/no): ")
    if confirm.lower() == 'yes':
        conn = get_conn()
        if not conn: return
        with conn.cursor() as cur:
            cur.execute("DELETE FROM complaint_log")
            conn.commit()
            print("✅ All data deleted.")
        conn.close()
    else:
        print("❌ Operation cancelled.")

def delete_specific():
    cid = input("\nEnter the Complaint ID to delete: ").strip()
    if not cid: return
    conn = get_conn()
    if not conn: return
    with conn.cursor() as cur:
        cur.execute("DELETE FROM complaint_log WHERE complaint_id = %s", (cid,))
        if cur.rowcount > 0:
            conn.commit()
            print(f"✅ Record {cid} deleted.")
        else:
            print(f"❌ No record found with ID: {cid}")
    conn.close()

def main_menu():
    while True:
        print("\n===== POSTGRES DATABASE MANAGER =====")
        print("1. Show all data")
        print("2. Delete specific data (by ID)")
        print("3. Delete ALL data")
        print("4. Exit")
        
        choice = input("\nSelect an option (1-4): ")
        
        if choice == '1':
            show_data()
        elif choice == '2':
            delete_specific()
        elif choice == '3':
            delete_all()
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice, try again.")

if __name__ == "__main__":
    main_menu()
