import multiprocessing

bind = "0.0.0.0:5050"
workers = multiprocessing.cpu_count() * 2 + 1

timeout = 120
accesslog = "-"
errorlog = "-"
capture_output = True
preload_app = False


def post_fork(server, worker):
    """
    If Flask-SQLAlchemy is added later, recycle inherited pools per worker.
    This avoids sharing parent process DB connections across gunicorn workers.
    """
    try:
        from wsgi import application

        db_ext = application.extensions.get("sqlalchemy")
        if db_ext is not None:
            db_ext.engine.dispose()
    except Exception:
        pass
