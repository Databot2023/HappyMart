"""
Windows development server runner.
Usage: python run_windows.py
"""
import sys

PORT = 5000
HOST = "127.0.0.1"

try:
    from app import app, bootstrap_runtime
except ImportError as e:
    print(f"[ERROR] Could not import app from app.py: {e}")
    print("[HINT] Make sure app.py exists in the same directory with a Flask instance named 'app'.")
    sys.exit(1)

if __name__ == "__main__":
    bootstrap_runtime()
    try:
        print(f"[*] Starting Flask dev server at http://{HOST}:{PORT}")
        print("[*] Press Ctrl+C to stop")
        app.run(host=HOST, port=PORT, debug=True)
    except OSError as e:
        if "address already in use" in str(e).lower() or "10048" in str(e):
            print(f"[ERROR] Port {PORT} is already in use. Choose a different port or kill the other process.")
        else:
            print(f"[ERROR] Could not start server: {e}")
        sys.exit(1)
