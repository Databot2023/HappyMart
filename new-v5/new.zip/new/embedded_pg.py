import atexit
import os
from pathlib import Path
from typing import Optional


_PG: Optional[object] = None


def _project_path(*parts: str) -> str:
    base = Path(__file__).resolve().parent
    return str(base.joinpath(*parts))


def _env_int(name: str, default: int) -> int:
    raw = (os.getenv(name, "") or "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def start_pg() -> str:
    """
    Start embedded PostgreSQL (pg0-embedded) with a project-local data directory.

    Returns a PostgreSQL connection URI (postgresql://...).
    """
    global _PG
    if _PG is not None:
        return getattr(_PG, "uri")

    # Lazy import so the app still runs without embedded postgres installed.
    from pg0 import Pg0  # type: ignore

    port = _env_int("EMBEDDED_PG_PORT", 5433)
    username = (os.getenv("EMBEDDED_PG_USER", "postgres") or "postgres").strip()
    password = (os.getenv("EMBEDDED_PG_PASSWORD", "postgres") or "postgres").strip()
    database = (os.getenv("EMBEDDED_PG_DB", "postgres") or "postgres").strip()

    data_dir = os.getenv("EMBEDDED_PG_DATA_DIR", "").strip() or _project_path("pgsql_data")
    Path(data_dir).mkdir(parents=True, exist_ok=True)

    _PG = Pg0(
        name="complaintdesk",
        port=port,
        username=username,
        password=password,
        database=database,
        data_dir=data_dir,
    )
    _PG.start()

    # Ensure the rest of the app uses this DB unless explicitly overridden.
    if not (os.getenv("APP_DATABASE_URL") or "").strip():
        os.environ["APP_DATABASE_URL"] = _PG.uri

    atexit.register(stop_pg)
    return _PG.uri


def stop_pg():
    global _PG
    if _PG is None:
        return
    try:
        _PG.stop()
    finally:
        _PG = None

