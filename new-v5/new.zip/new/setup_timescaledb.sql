-- ============================================================
-- ComplaintDesk — TimescaleDB Setup
-- Run once against the complaint_logs database:
--   psql -U postgres -d complaint_logs -f setup_timescaledb.sql
-- ============================================================

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- ── Main archive table ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS completed_complaints (
    id                    BIGSERIAL PRIMARY KEY,
    complaint_id          VARCHAR(50)  UNIQUE NOT NULL,
    completion_date       TIMESTAMPTZ  NOT NULL,
    place                 VARCHAR(200),
    complaint_note        TEXT,
    finisher_profile_name VARCHAR(100),
    finisher_user_id      BIGINT,
    resolution_time_hours FLOAT,
    satisfaction_score    INT CHECK (satisfaction_score BETWEEN 1 AND 5),
    attachments           JSONB,
    created_at            TIMESTAMPTZ  DEFAULT NOW(),
    updated_at            TIMESTAMPTZ  DEFAULT NOW()
);

-- ── Convert to TimescaleDB hypertable (30-day chunks) ─────────
SELECT create_hypertable(
    'completed_complaints',
    'completion_date',
    chunk_time_interval => INTERVAL '30 days',
    if_not_exists       => TRUE
);

-- ── Indexes for fast queries ──────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_completion_date   ON completed_complaints (completion_date DESC);
CREATE INDEX IF NOT EXISTS idx_finisher_profile  ON completed_complaints (finisher_profile_name);
CREATE INDEX IF NOT EXISTS idx_place             ON completed_complaints (place);
CREATE INDEX IF NOT EXISTS idx_complaint_id      ON completed_complaints (complaint_id);

-- ── Compression: segment by finisher, order by date desc ─────
ALTER TABLE completed_complaints SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'finisher_profile_name',
    timescaledb.compress_orderby   = 'completion_date DESC'
);

-- ── Auto-compress chunks older than 180 days ──────────────────
SELECT add_compression_policy(
    'completed_complaints',
    INTERVAL '180 days',
    if_not_exists => TRUE
);

-- ── Confirmation ──────────────────────────────────────────────
SELECT 'TimescaleDB setup complete.' AS status;
