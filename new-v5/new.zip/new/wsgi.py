from app import app, bootstrap_runtime

# Initialize background tasks and DB
bootstrap_runtime()

# On Windows, use Waitress to serve the application:
# pip install waitress
# waitress-serve --port=5050 wsgi:application
application = app
