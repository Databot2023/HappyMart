#!/usr/bin/env bash

set -Eeuo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${PROJECT_DIR}/.venv"
LOG_DIR="${PROJECT_DIR}/logs"
APP_LOG="${LOG_DIR}/app.log"

mkdir -p "${LOG_DIR}"

log() {
    echo "[$(date +"%Y-%m-%d %H:%M:%S")] $*" | tee -a "${APP_LOG}"
}

# Fix line endings of .env if needed
if [[ -f ".env" ]]; then
    sed -i 's/\r$//' .env 2>/dev/null || true
fi

# Check if already running
if pgrep -f "waitress_server.py" > /dev/null; then
    log "⚠️  Application already running. Stop it first with: ./stop.sh"
    exit 1
fi

cd "${PROJECT_DIR}"

# Setup Python venv if not exists
if [[ ! -d "${VENV_DIR}" ]]; then
    log "📦 Creating virtual environment..."
    python3 -m venv "${VENV_DIR}"
fi

# Activate venv
source "${VENV_DIR}/bin/activate"

# Install dependencies
log "📥 Installing dependencies..."
pip install --upgrade pip > /dev/null 2>&1
pip install flask waitress psycopg2-binary python-dotenv > /dev/null 2>&1

# Load environment variables
if [[ -f ".env" ]]; then
    set -a
    source .env
    set +a
else
    log "⚠️  .env file not found, creating default..."
    cat > .env << 'EOF'
HOST=0.0.0.0
PORT=8080
APP_DATABASE_URL=postgresql://postgres:admin916@localhost:5432/complaint_logs
EOF
fi

# Setup database
log "🐘 Setting up PostgreSQL..."
if ! pg_isready > /dev/null 2>&1; then
    sudo systemctl start postgresql 2>/dev/null || true
    sleep 2
fi

# Create database if not exists
psql -U postgres -tc "SELECT 1 FROM pg_database WHERE datname = 'complaint_logs'" 2>/dev/null | grep -q 1 || \
    psql -U postgres -c "CREATE DATABASE complaint_logs" 2>/dev/null || \
    log "⚠️  Could not create database (may already exist)"

# Run your app's database initialization
python -c "from app import init_db; init_db()" 2>/dev/null || log "⚠️  init_db() not found, skipping"

# Start the server
PORT=${PORT:-8080}
HOST=${HOST:-192.168.110.132}
log "🚀 Starting Waitress on http://${HOST}:${PORT}"
nohup python waitress_server.py >> "${APP_LOG}" 2>&1 &

echo $! > "${PROJECT_DIR}/.pid"
log "✅ Started with PID: $(cat ${PROJECT_DIR}/.pid)"
log "📝 Logs: ${APP_LOG}"
