from dotenv import load_dotenv
import os
import psycopg2
from psycopg2.extras import RealDictCursor

load_dotenv()
url = os.getenv('TIMESCALE_URL')

if not url:
    print('Error: TIMESCALE_URL not found in .env')
    exit(1)

try:
    conn = psycopg2.connect(url)
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    # Check if table exists
    cur.execute("""
        SELECT EXISTS (
            SELECT FROM information_schema.tables 
            WHERE table_name = 'complaint_log'
        );
    """)
    exists = cur.fetchone()['exists']
    
    if not exists:
        print('Table "complaint_log" does not exist in PostgreSQL.')
    else:
        cur.execute('SELECT * FROM complaint_log ORDER BY completion_date DESC LIMIT 50')
        rows = cur.fetchall()
        
        if not rows:
            print('No data found in "complaint_log" table.')
        else:
            print(f'Found {len(rows)} records in complaint_log:')
            print('-' * 80)
            for r in rows:
                print(f"ID: {r['complaint_id']} | Date: {r['completion_date']} | Place: {r['place']}")
                print(f"Note: {r['complaint_note']}")
                print(f"By: {r['finisher_profile_name']} (UID: {r['finisher_user_id']})")
                print('-' * 80)
                
    cur.close()
    conn.close()
except Exception as e:
    print(f'PostgreSQL Error: {e}')
