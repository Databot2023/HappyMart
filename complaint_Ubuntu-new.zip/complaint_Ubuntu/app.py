from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from datetime import datetime, timedelta
import os
import sys

import json
import secrets
import threading
from functools import wraps
import re
import sqlite3
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
import psycopg2
import psycopg2.extras
import timescale_db

# Load environment variables from .env
load_dotenv()

app = Flask(__name__)

# Trust reverse-proxy headers (Cloudflare Tunnel sets these).
# This is required for correct scheme/remote IP handling behind a proxy.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# Security: Enforce SECRET_KEY and limit request size
app.secret_key = os.getenv('SECRET_KEY')
if not app.secret_key:
    raise RuntimeError("FATAL: SECRET_KEY is not set in environment (.env).")

app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit

def _env_bool(name: str, default: bool) -> bool:
    raw = os.getenv(name, '')
    if raw is None or str(raw).strip() == '':
        return default
    return str(raw).strip().lower() not in {'0', 'false', 'no', 'off'}

def _cookie_secure_setting() -> bool:
    """
    Secure cookies must be OFF for plain HTTP access (otherwise the browser drops the cookie).

    Policy:
    - COOKIE_SECURE=true/false explicitly overrides everything.
    - Otherwise default to AUTO:
      - enable Secure cookies only when an HTTPS proxy/tunnel is in front
        (set COOKIE_SECURE_AUTO_HTTPS=1 in that deployment).
      - keep insecure cookies for direct HTTP (e.g. http://<ip>:5050).
    """
    if os.getenv('COOKIE_SECURE', '').strip() != '':
        return _env_bool('COOKIE_SECURE', True)
    return _env_bool('COOKIE_SECURE_AUTO_HTTPS', False)

cookie_secure = _cookie_secure_setting()
cookie_domain = (os.getenv('SESSION_COOKIE_DOMAIN', '') or '').strip() or None
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE=os.getenv('SESSION_COOKIE_SAMESITE', 'Lax'),
    SESSION_COOKIE_SECURE=cookie_secure,
    SESSION_COOKIE_DOMAIN=cookie_domain,
)

APP_DATABASE_URL = os.getenv('APP_DATABASE_URL', '').strip() or os.getenv('TIMESCALE_URL', '').strip()
DB_BACKEND = (os.getenv('DB_BACKEND', 'auto') or 'auto').strip().lower()
SQLITE_PATH = (os.getenv('SQLITE_PATH', '') or '').strip()
ENV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
ADMIN_LIMIT = 5
ADMIN_ACCOUNTS = []
ADMIN_MAP = {}
SYNC_RETRY_SCHEDULE_MINUTES = [1, 5, 15, 60, 360, 720, 1440]
SYNC_MAX_RETRY_HOURS = 48
SYNC_SCAN_INTERVAL_SECONDS = 30 * 60
_SYNC_WORKER_STARTED = False
_SYNC_WORKER_LOCK = threading.Lock()

def is_password_hash(value):
    return isinstance(value, str) and (value.startswith('scrypt:') or value.startswith('pbkdf2:'))

def password_matches(stored, plain):
    if not stored:
        return False
    if is_password_hash(stored):
        try:
            return check_password_hash(stored, plain)
        except ValueError:
            return False
    return stored == plain

def parse_admin_accounts(raw):
    try:
        parsed = json.loads(raw) if raw else []
    except json.JSONDecodeError:
        parsed = []
    if not isinstance(parsed, list):
        parsed = []
    admins = []
    for item in parsed[:ADMIN_LIMIT]:
        if not isinstance(item, dict):
            continue
        username = str(item.get('username', '')).strip()
        password = str(item.get('password', '')).strip()
        display_name = str(item.get('display_name') or username).strip()
        if username and password:
            admins.append({
                'username': username,
                'password': password,
                'display_name': display_name or username
            })
    return admins

def refresh_admin_cache():
    global ADMIN_ACCOUNTS, ADMIN_MAP
    admin_accounts_raw = os.getenv('ADMIN_ACCOUNTS', '')
    admins = parse_admin_accounts(admin_accounts_raw)
    
    # Super Admin from .env
    super_user = os.getenv('SUPER_ADMIN_USERNAME', '').strip().strip('"').strip("'")
    super_pass = os.getenv('SUPER_ADMIN_PASSWORD', '').strip().strip('"').strip("'")
    
    legacy_user = os.getenv('ADMIN_USERNAME', '').strip().strip('"').strip("'")
    legacy_pass = os.getenv('ADMIN_PASSWORD', '').strip().strip('"').strip("'")
    
    if not admins and legacy_user and legacy_pass:
        admins = [{
            'username': legacy_user,
            'password': legacy_pass,
            'display_name': legacy_user
        }]
    
    ADMIN_ACCOUNTS = admins[:ADMIN_LIMIT]
    ADMIN_MAP = {a['username']: a for a in ADMIN_ACCOUNTS}
    
    # Inject Super Admin into MAP if not already there
    if super_user and super_pass:
        if super_user not in ADMIN_MAP:
            ADMIN_MAP[super_user] = {
                'username': super_user,
                'password': super_pass,
                'display_name': 'Super Admin'
            }

def get_admin_count():
    refresh_admin_cache()
    # "Admin slots" are based on ADMIN_ACCOUNTS (config-driven admin list),
    # but we must exclude disabled/deleted usernames to avoid showing stale counts.
    try:
        conn = get_db()
        try:
            _init_disabled_accounts(conn)
            disabled = {
                (r.get('username') if isinstance(r, dict) else None)
                for r in conn.execute("SELECT username FROM disabled_accounts").fetchall()
            }
            disabled.discard(None)
        finally:
            conn.close()
    except Exception:
        disabled = set()
    return len([a for a in ADMIN_ACCOUNTS if a.get('username') not in disabled])

def is_admin_limit_reached():
    return get_admin_count() >= ADMIN_LIMIT

def add_admin_to_env(username, password, display_name):
    refresh_admin_cache()
    admins = []
    for a in ADMIN_ACCOUNTS:
        admins.append({
            'username': a['username'],
            'password': a['password'] if is_password_hash(a['password']) else generate_password_hash(a['password']),
            'display_name': a['display_name']
        })
    if len(admins) >= ADMIN_LIMIT:
        return False, 'Admin limit reached.'
    if any(a['username'] == username for a in admins):
        # Allow re-creating a previously deleted/disabled username by overwriting
        # its ADMIN_ACCOUNTS entry and re-enabling it in the DB.
        conn = get_db()
        try:
            _init_disabled_accounts(conn)
            if not is_account_disabled(conn, username):
                return False, 'Username already exists.'
            enable_account(conn, username)
            conn.commit()
        finally:
            conn.close()
        for a in admins:
            if a['username'] == username:
                a['password'] = generate_password_hash(password)
                a['display_name'] = display_name
                break
        raw = f"ADMIN_ACCOUNTS='{json.dumps(admins, separators=(',', ':'))}'"
        lines = []
        if os.path.exists(ENV_PATH):
            with open(ENV_PATH, 'r', encoding='utf-8') as f:
                lines = f.read().splitlines()
        replaced = False
        for i, line in enumerate(lines):
            if line.strip().startswith('ADMIN_ACCOUNTS='):
                lines[i] = raw
                replaced = True
                break
        if not replaced:
            lines.append(raw)
        with open(ENV_PATH, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines).rstrip() + '\n')
        os.environ['ADMIN_ACCOUNTS'] = json.dumps(admins, separators=(',', ':'))
        refresh_admin_cache()
        return True, None
    admins.append({
        'username': username,
        'password': generate_password_hash(password),
        'display_name': display_name
    })
    raw = f"ADMIN_ACCOUNTS='{json.dumps(admins, separators=(',', ':'))}'"
    lines = []
    if os.path.exists(ENV_PATH):
        with open(ENV_PATH, 'r', encoding='utf-8') as f:
            lines = f.read().splitlines()
    replaced = False
    for i, line in enumerate(lines):
        if line.strip().startswith('ADMIN_ACCOUNTS='):
            lines[i] = raw
            replaced = True
            break
    if not replaced:
        lines.append(raw)
    with open(ENV_PATH, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines).rstrip() + '\n')
    os.environ['ADMIN_ACCOUNTS'] = json.dumps(admins, separators=(',', ':'))
    refresh_admin_cache()
    return True, None

refresh_admin_cache()

def parse_datetime_input(value):
    value = (value or '').strip()
    if not value:
        return None

    for fmt in ('%Y-%m-%dT%H:%M', '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):
        try:
            return datetime.strptime(value, fmt).strftime('%Y-%m-%d %H:%M:%S')
        except ValueError:
            continue
    return None

def _to_pg_sql(query: str) -> str:
    """Convert sqlite-style placeholders to psycopg2 placeholders."""
    return query.replace('?', '%s')

class DbCursorAdapter:
    def __init__(self, cursor):
        self._cursor = cursor

    def fetchone(self):
        return self._cursor.fetchone()

    def fetchall(self):
        return self._cursor.fetchall()

    @property
    def rowcount(self):
        return self._cursor.rowcount

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

class DbConnAdapter:
    def __init__(self, raw_conn):
        self._conn = raw_conn
        self.backend = 'postgres'

    def execute(self, query, params=None):
        cur = self._conn.cursor()
        cur.execute(_to_pg_sql(query), params or ())
        return DbCursorAdapter(cur)

    def cursor(self):
        return self._conn.cursor()

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()

class SqliteCursorAdapter:
    def __init__(self, cursor):
        self._cursor = cursor

    def fetchone(self):
        row = self._cursor.fetchone()
        return dict(row) if row is not None else None

    def fetchall(self):
        rows = self._cursor.fetchall()
        return [dict(r) for r in rows]

    @property
    def lastrowid(self):
        return self._cursor.lastrowid

    @property
    def rowcount(self):
        return self._cursor.rowcount


class SqliteConnAdapter:
    def __init__(self, raw_conn):
        self._conn = raw_conn
        self.backend = 'sqlite'

    def execute(self, query, params=None):
        cur = self._conn.cursor()
        cur.execute(query, params or ())
        return SqliteCursorAdapter(cur)

    def cursor(self):
        return self._conn.cursor()

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()

def _default_sqlite_path() -> str:
    base = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base, 'data')
    os.makedirs(data_dir, exist_ok=True)
    return os.path.join(data_dir, 'complaints.db')

def _sqlite_connect(path: str):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn

def get_db():
    """
    Database selection (portable by default).

    - DB_BACKEND=auto (default):
      - if APP_DATABASE_URL is set: PostgreSQL
      - else: SQLite file in ./data/complaints.db
    - DB_BACKEND=postgres: force PostgreSQL
    - DB_BACKEND=sqlite: force SQLite
    """
    backend = DB_BACKEND
    if backend not in {'auto', 'postgres', 'sqlite'}:
        backend = 'auto'

    # Read current env at call time (embedded postgres may set APP_DATABASE_URL on startup).
    app_db_url = (os.getenv('APP_DATABASE_URL', '').strip()
                  or os.getenv('TIMESCALE_URL', '').strip())

    if backend == 'postgres' or (backend == 'auto' and app_db_url):
        if not app_db_url:
            raise RuntimeError("APP_DATABASE_URL is not set but DB_BACKEND=postgres was requested.")
        try:
            raw = psycopg2.connect(app_db_url, cursor_factory=psycopg2.extras.RealDictCursor)
            return DbConnAdapter(raw)
        except psycopg2.OperationalError as e:
            print(f"CRITICAL: Could not connect to PostgreSQL at {app_db_url}")
            print(f"ERROR DETAILS: {e}")
            raise

    path = SQLITE_PATH or _default_sqlite_path()
    try:
        return SqliteConnAdapter(_sqlite_connect(path))
    except sqlite3.Error as e:
        print(f"CRITICAL: Could not open SQLite DB at {path}")
        print(f"ERROR DETAILS: {e}")
        raise


def now_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def parse_stored_datetime(value):
    if not value:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    return None

def get_retry_delay_minutes(attempts):
    if attempts <= 0:
        return 0
    idx = min(attempts - 1, len(SYNC_RETRY_SCHEDULE_MINUTES) - 1)
    return SYNC_RETRY_SCHEDULE_MINUTES[idx]

def build_complaint_payload(cid, conn=None):
    owns_conn = conn is None
    if owns_conn:
        conn = get_db()
    row = conn.execute(
        '''
        SELECT c.id, c.created_at, c.note, c.completed_at, p.name AS place
        FROM complaints c
        JOIN places p ON c.place_id = p.id
        WHERE c.id=? AND c.is_completed=1
        ''',
        (cid,)
    ).fetchone()
    if owns_conn:
        conn.close()
    if not row:
        return None
    return {
        'complaint_id': row['id'],
        'created_at': row['created_at'] or '',
        'place': row['place'] or '',
        'note': row['note'] or '',
        'completed_at': row['completed_at'] or ''
    }

def enqueue_failed_sync(complaint_data, error_msg):
    conn = get_db()
    conn.execute(
        '''
        INSERT INTO sync_queue (complaint_data, status, attempts, last_attempt, created_at, error_msg)
        VALUES (?, 'pending', 0, NULL, ?, ?)
        ''',
        (json.dumps(complaint_data, separators=(',', ':')), now_str(), (str(error_msg) or '')[:500])
    )
    conn.commit()
    conn.close()

def mark_queue_item_completed(queue_id):
    conn = get_db()
    conn.execute(
        '''
        UPDATE sync_queue
        SET status='completed', last_attempt=?, error_msg=NULL
        WHERE id=?
        ''',
        (now_str(), queue_id)
    )
    conn.commit()
    conn.close()

def update_queue_item_failure(item, error_msg):
    created_dt = parse_stored_datetime(item['created_at']) or datetime.now()
    age = datetime.now() - created_dt
    new_attempts = int(item['attempts'] or 0) + 1
    new_status = 'retrying'
    if age >= timedelta(hours=SYNC_MAX_RETRY_HOURS):
        new_status = 'failed_permanent'
        print(f"ALERT [sync_queue]: Permanent failure for queue item #{item['id']} after 48h.")
    conn = get_db()
    conn.execute(
        '''
        UPDATE sync_queue
        SET status=?, attempts=?, last_attempt=?, error_msg=?
        WHERE id=?
        ''',
        (new_status, new_attempts, now_str(), (str(error_msg) or '')[:500], item['id'])
    )
    conn.commit()
    conn.close()


def sync_all_to_archive():
    """
    Find all complaints in SQLite and ensure they are archived in TimescaleDB/PostgreSQL.
    """
    try:
        conn = get_db()
        all_complaints = conn.execute('''
            SELECT c.*, p.name AS place_name
            FROM complaints c
            JOIN places p ON c.place_id = p.id
        ''').fetchall()
        conn.close()

        if not all_complaints:
            return 0, 0

        payloads = []
        for row in all_complaints:
            payloads.append({
                'complaint_id':          str(row['id']),
                'completion_date':       row['completed_at'],
                'place':                 row['place_name'] or '',
                'complaint_note':        row['note'] or '',
                'finisher_profile_name': row['completed_by'] or '',
                'finisher_user_id':      None,
                'created_at':            row['created_at'] or '',
            })
        
        ok, err = timescale_db.bulk_archive_completed_complaints(payloads)
        if ok:
            return len(payloads), 0
        else:
            return 0, len(payloads)
    except Exception as e:
        print(f"[sync] Error during auto-sync: {e}")
        return 0, 0


def should_retry_item(item):
    if item['status'] == 'failed_permanent':
        return False
    created_dt = parse_stored_datetime(item['created_at'])
    if created_dt and (datetime.now() - created_dt) >= timedelta(hours=SYNC_MAX_RETRY_HOURS):
        update_queue_item_failure(item, item['error_msg'] or 'Retry window exceeded 48 hours')
        return False
    attempts = int(item['attempts'] or 0)
    if attempts <= 0:
        return True
    last_attempt_dt = parse_stored_datetime(item['last_attempt'])
    if not last_attempt_dt:
        return True
    delay_minutes = get_retry_delay_minutes(attempts)
    return datetime.now() >= (last_attempt_dt + timedelta(minutes=delay_minutes))

def retry_sync_queue(run_all=False):
    # Google Sheet sync was removed, so queue retries are now a no-op.
    return 0, 0

def get_sync_status_snapshot():
    conn = get_db()
    pending_row = conn.execute(
        "SELECT COUNT(*) AS cnt FROM sync_queue WHERE status IN ('pending', 'retrying')"
    ).fetchone()
    failed_row = conn.execute(
        "SELECT COUNT(*) AS cnt FROM sync_queue WHERE status='failed_permanent'"
    ).fetchone()
    old_fail_row = conn.execute(
        '''
        SELECT COUNT(*) AS cnt
        FROM sync_queue
        WHERE status='failed_permanent'
          AND created_at <= ?
        ''',
        ((datetime.now() - timedelta(hours=24)).strftime('%Y-%m-%d %H:%M:%S'),)
    ).fetchone()
    last_success_row = conn.execute(
        "SELECT MAX(last_attempt) AS last_success FROM sync_queue WHERE status='completed'"
    ).fetchone()
    conn.close()
    pending = int(pending_row['cnt'] or 0)
    failed = int(failed_row['cnt'] or 0)
    failed_over_24h = int(old_fail_row['cnt'] or 0)
    queue_health = 'good'
    badge_color = 'green'
    if failed_over_24h > 0:
        queue_health = 'critical'
        badge_color = 'red'
    elif pending > 0 or failed > 0:
        queue_health = 'warning'
        badge_color = 'yellow'
    return {
        'pending': pending,
        'failed': failed,
        'last_success': last_success_row['last_success'] if last_success_row else None,
        'queue_health': queue_health,
        'badge_color': badge_color
    }

def sync_retry_worker_loop():
    while True:
        try:
            # 1. Retry failed syncs
            retry_sync_queue(run_all=False)
            
            # 2. Cleanup old records (Every loop, which is 30 mins by default)
            # This prevents SD card wear compared to running it on every request.
            cutoff = (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d %H:%M:%S')
            conn = get_db()
            conn.execute("DELETE FROM complaints WHERE is_completed=1 AND completed_at <= ?", (cutoff,))
            conn.commit()
            conn.close()
            print(f"INFO [worker]: Cleanup completed for records older than {cutoff}")
            
        except Exception as exc:
            print(f"ERROR [worker loop]: {exc}")
        threading.Event().wait(SYNC_SCAN_INTERVAL_SECONDS)


def start_sync_retry_worker():
    global _SYNC_WORKER_STARTED
    with _SYNC_WORKER_LOCK:
        if _SYNC_WORKER_STARTED:
            return
        worker = threading.Thread(target=sync_retry_worker_loop, daemon=True)
        worker.start()
        _SYNC_WORKER_STARTED = True

def client_ip():
    # Prefer proxy-provided "real client IP" headers when present.
    # Cloudflare Tunnel sets CF-Connecting-IP; other proxies commonly set X-Forwarded-For.
    cf = (request.headers.get('CF-Connecting-IP', '') or '').strip()
    if cf:
        return cf
    xff = (request.headers.get('X-Forwarded-For', '') or '').split(',')[0].strip()
    return xff or (request.remote_addr or '')

def client_device():
    return request.headers.get('User-Agent', '')[:255]

def clear_db_session(user_id, token=None):
    conn = get_db()
    if token:
        conn.execute("DELETE FROM sessions WHERE user_id=? OR session_token=?", (user_id, token))
    else:
        conn.execute("DELETE FROM sessions WHERE user_id=?", (user_id,))
    conn.commit()
    conn.close()

def create_db_session(user_id):
    token = secrets.token_urlsafe(32)
    conn = get_db()
    conn.execute(
        "INSERT INTO sessions (user_id, session_token, ip, device_info, created_at) VALUES (?, ?, ?, ?, ?)",
        (user_id, token, client_ip(), client_device(), datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    )
    conn.commit()
    conn.close()
    return token

def is_active_db_session(user_id, token):
    bind_ip = _env_bool('SESSION_BIND_IP', False)
    conn = get_db()
    if bind_ip:
        row = conn.execute(
            "SELECT 1 FROM sessions WHERE user_id=? AND session_token=? AND ip=? AND device_info=?",
            (user_id, token, client_ip(), client_device())
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT 1 FROM sessions WHERE user_id=? AND session_token=? AND device_info=?",
            (user_id, token, client_device())
        ).fetchone()
    conn.close()
    return row is not None

def has_active_db_session(user_id):
    conn = get_db()
    row = conn.execute("SELECT 1 FROM sessions WHERE user_id=?", (user_id,)).fetchone()
    conn.close()
    return row is not None

_GMAIL_RE = re.compile(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@gmail\.com$")

def normalize_gmail(value: str) -> str:
    return (value or '').strip().lower()

def is_valid_gmail(value: str) -> bool:
    value = normalize_gmail(value)
    if not value:
        return True
    return _GMAIL_RE.match(value) is not None

def set_user_session(user_row):
    token = create_db_session(user_row['id'])
    session['user_id'] = user_row['id']
    session['username'] = user_row['username']
    session['display_name'] = user_row['display_name'] or user_row['username']
    session['role'] = user_row['role']
    session['session_token'] = token

# ─── DECORATORS ───────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        refresh_admin_cache()
        if 'user_id' not in session:
            return redirect(url_for('admin_login'))
        if session.get('role') != 'admin' or session.get('username') not in ADMIN_MAP:
            session.clear()
            flash('Admin credentials changed or session expired. Please log in again.', 'error')
            return redirect(url_for('admin_login'))
        if not session.get('display_name'):
            session['display_name'] = ADMIN_MAP.get(session.get('username'), {}).get('display_name', session.get('username'))
        return f(*args, **kwargs)
    return decorated_function

def super_admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        refresh_admin_cache()
        if 'user_id' not in session:
            return redirect(url_for('admin_login'))
        if session.get('role') != 'admin' or not session.get('is_super_admin'):
            flash('This action requires Super Admin privileges.', 'error')
            return redirect(url_for('admin_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def _sqlite_has_column(conn: SqliteConnAdapter, table: str, column: str) -> bool:
    cur = conn.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    cols = [r[1] for r in cur.fetchall()]  # (cid, name, type, notnull, dflt_value, pk)
    return column in cols

def _sqlite_add_column_if_missing(conn: SqliteConnAdapter, table: str, column: str, col_def: str):
    if _sqlite_has_column(conn, table, column):
        return
    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {col_def}")

def _init_disabled_accounts(conn):
    if getattr(conn, 'backend', 'postgres') == 'sqlite':
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS disabled_accounts (
                username TEXT PRIMARY KEY,
                disabled_at TEXT NOT NULL
            )
            """
        )
        return
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS disabled_accounts (
            username TEXT PRIMARY KEY,
            disabled_at TEXT NOT NULL
        )
        """
    )

def is_account_disabled(conn, username: str) -> bool:
    if not username:
        return False
    row = conn.execute("SELECT 1 AS ok FROM disabled_accounts WHERE username=?", (username,)).fetchone()
    return row is not None

def disable_account(conn, username: str):
    if not username:
        return
    # idempotent insert
    if getattr(conn, 'backend', 'postgres') == 'sqlite':
        conn.execute(
            "INSERT OR REPLACE INTO disabled_accounts (username, disabled_at) VALUES (?, ?)",
            (username, now_str()),
        )
    else:
        conn.execute(
            "INSERT INTO disabled_accounts (username, disabled_at) VALUES (?, ?) ON CONFLICT (username) DO UPDATE SET disabled_at=EXCLUDED.disabled_at",
            (username, now_str()),
        )

def enable_account(conn, username: str):
    if not username:
        return
    conn.execute("DELETE FROM disabled_accounts WHERE username=?", (username,))

def init_db():
    conn = get_db()
    if getattr(conn, 'backend', 'postgres') == 'sqlite':
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                display_name TEXT DEFAULT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                is_approved INTEGER DEFAULT 0,
                is_super_admin INTEGER DEFAULT 0,
                google_email TEXT DEFAULT NULL,
                gmail TEXT DEFAULT NULL,
                gmail_verified INTEGER DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS places (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS complaints (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                place_id INTEGER NOT NULL,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL,
                created_by TEXT DEFAULT NULL,
                is_read INTEGER DEFAULT 0,
                is_completed INTEGER DEFAULT 0,
                completed_at TEXT DEFAULT NULL,
                completed_by TEXT DEFAULT NULL,
                FOREIGN KEY(place_id) REFERENCES places(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                session_token TEXT UNIQUE NOT NULL,
                ip TEXT,
                device_info TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_queue (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                complaint_data TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0,
                last_attempt TEXT DEFAULT NULL,
                created_at TEXT NOT NULL,
                error_msg TEXT DEFAULT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS gmail_otps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                gmail TEXT NOT NULL,
                otp_hash TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                is_verified INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
            )
            """
        )

        # Backward-compatible column migrations (SQLite)
        _sqlite_add_column_if_missing(conn, 'users', 'is_super_admin', 'INTEGER DEFAULT 0')
        _sqlite_add_column_if_missing(conn, 'complaints', 'is_completed', 'INTEGER DEFAULT 0')
        _sqlite_add_column_if_missing(conn, 'complaints', 'completed_at', 'TEXT DEFAULT NULL')
        _sqlite_add_column_if_missing(conn, 'users', 'display_name', 'TEXT DEFAULT NULL')
        _sqlite_add_column_if_missing(conn, 'users', 'google_email', 'TEXT DEFAULT NULL')
        _sqlite_add_column_if_missing(conn, 'users', 'gmail', 'TEXT DEFAULT NULL')
        _sqlite_add_column_if_missing(conn, 'users', 'gmail_verified', 'INTEGER DEFAULT 0')
        _sqlite_add_column_if_missing(conn, 'complaints', 'created_by', 'TEXT DEFAULT NULL')
        _sqlite_add_column_if_missing(conn, 'complaints', 'completed_by', 'TEXT DEFAULT NULL')
    else:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id BIGSERIAL PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                display_name TEXT DEFAULT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                is_approved INTEGER DEFAULT 0,
                is_super_admin INTEGER DEFAULT 0
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS places (
                id BIGSERIAL PRIMARY KEY,
                name TEXT UNIQUE NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS complaints (
                id BIGSERIAL PRIMARY KEY,
                place_id BIGINT NOT NULL REFERENCES places(id) ON DELETE CASCADE,
                note TEXT NOT NULL,
                created_at TEXT NOT NULL,
                created_by TEXT DEFAULT NULL,
                is_read INTEGER DEFAULT 0,
                is_completed INTEGER DEFAULT 0,
                completed_at TEXT DEFAULT NULL,
                completed_by TEXT DEFAULT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sessions (
                id BIGSERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                session_token TEXT UNIQUE NOT NULL,
                ip TEXT,
                device_info TEXT,
                created_at TEXT NOT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_queue (
                id BIGSERIAL PRIMARY KEY,
                complaint_data TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                attempts INTEGER NOT NULL DEFAULT 0,
                last_attempt TEXT DEFAULT NULL,
                created_at TEXT NOT NULL,
                error_msg TEXT DEFAULT NULL
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS gmail_otps (
                id BIGSERIAL PRIMARY KEY,
                user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                gmail TEXT NOT NULL,
                otp_hash TEXT NOT NULL,
                attempts INTEGER NOT NULL DEFAULT 0,
                expires_at TEXT NOT NULL,
                created_at TEXT NOT NULL,
                is_verified INTEGER NOT NULL DEFAULT 0
            )
            """
        )

        # Backward-compatible column migrations (PostgreSQL)
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS is_super_admin INTEGER DEFAULT 0")
        conn.execute("ALTER TABLE complaints ADD COLUMN IF NOT EXISTS is_completed INTEGER DEFAULT 0")
        conn.execute("ALTER TABLE complaints ADD COLUMN IF NOT EXISTS completed_at TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS display_name TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS google_email TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS gmail TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS gmail_verified INTEGER DEFAULT 0")
        conn.execute("ALTER TABLE complaints ADD COLUMN IF NOT EXISTS created_by TEXT DEFAULT NULL")
        conn.execute("ALTER TABLE complaints ADD COLUMN IF NOT EXISTS completed_by TEXT DEFAULT NULL")

    _init_disabled_accounts(conn)

    refresh_admin_cache()

    # ── Seed Super Admin FIRST (always ensure it exists) ──────────────────────
    super_user = os.getenv('SUPER_ADMIN_USERNAME', '').strip()
    super_pass = os.getenv('SUPER_ADMIN_PASSWORD', '').strip()
    if super_user and super_pass:
        if is_account_disabled(conn, super_user):
            print("WARN: Super Admin username is disabled in DB; skipping super admin seed.")
        else:
            existing = conn.execute("SELECT id FROM users WHERE username=?", (super_user,)).fetchone()
            if existing:
                conn.execute(
                    "UPDATE users SET password=?, role='admin', is_approved=1, is_super_admin=1 WHERE id=?",
                    (super_pass, existing['id'])
                )
            else:
                conn.execute(
                    "INSERT INTO users (username, password, display_name, role, is_approved, is_super_admin) VALUES (?, ?, ?, 'admin', 1, 1)",
                    (super_user, super_pass, 'Super Admin')
                )

    # Seed default sample users
    for u, p in [('user1', 'pass1'), ('user2', 'pass2'), ('user3', 'pass3')]:
        if is_account_disabled(conn, u):
            continue
        if not conn.execute("SELECT 1 FROM users WHERE username=?", (u,)).fetchone():
            conn.execute(
                "INSERT INTO users (username, password, display_name, role, is_approved) VALUES (?, ?, ?, ?, ?)",
                (u, p, u, 'user', 1),
            )

    # Seed admins from ADMIN_ACCOUNTS
    for admin in ADMIN_ACCOUNTS:
        admin_username = admin['username']
        admin_pass = admin['password']
        admin_display = admin['display_name']
        if is_account_disabled(conn, admin_username):
            continue
        row = conn.execute("SELECT id FROM users WHERE username=?", (admin_username,)).fetchone()
        if row:
            conn.execute(
                "UPDATE users SET password=?, display_name=?, role='admin', is_approved=1 WHERE id=?",
                (admin_pass, admin_display, row['id'])
            )
        else:
            conn.execute(
                "INSERT INTO users (username, password, display_name, role, is_approved) VALUES (?, ?, ?, 'admin', 1)",
                (admin_username, admin_pass, admin_display)
            )
    # Seed sample places only if table is empty
    places_count = conn.execute("SELECT COUNT(*) AS cnt FROM places").fetchone()["cnt"]
    if int(places_count or 0) == 0:
        for place in ['Main Hall', 'Block A', 'Block B', 'Cafeteria', 'Library', 'Sports Ground']:
            conn.execute("INSERT INTO places (name) VALUES (?)", (place,))
    conn.execute("UPDATE users SET display_name=username WHERE display_name IS NULL OR TRIM(display_name)=''")

    conn.commit()
    conn.close()

    # ── TimescaleDB: try auto-starting PostgreSQL service (Windows only) ─────
    try:
        ts_boot = timescale_db.try_auto_start_postgres()
        if ts_boot.get('started'):
            print(f"[timescale_db] Auto-start: {ts_boot.get('message')}")
        elif ts_boot.get('attempted'):
            print(f"[timescale_db] Auto-start warning: {ts_boot.get('message')}")
        else:
            print(f"[timescale_db] Auto-start skipped: {ts_boot.get('message')}")
    except Exception as _ts_boot_err:
        print(f"[timescale_db] Auto-start check failed: {_ts_boot_err}")

    # ── TimescaleDB: create schema (non-fatal) ────────────────────────────────
    try:
        timescale_db.init_timescale_db()
    except Exception as _ts_err:
        print(f"[timescale_db] Startup init skipped: {_ts_err}")

@app.before_request
def startup_maintenance():
    # Only start the background worker; cleanup is now handled there.
    start_sync_retry_worker()


@app.before_request
def verify_active_session():
    if request.endpoint in {'login', 'register', 'admin_login', 'logout', 'static'}:
        return
    if 'user_id' not in session or session.get('role') != 'user':
        return
    token = session.get('session_token')
    if not token or not is_active_db_session(session['user_id'], token):
        session.clear()
        flash('Logged out: your account was used on another device.', 'error')
        return redirect(url_for('login'))

@app.route('/')
def index():
    if 'user_id' in session:
        if session['role'] == 'admin':
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('user_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session.clear()
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        
        # Check Database for Users only
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE username=? AND password=? AND role='user'",
                            (username, password)).fetchone()
        conn.close()
        
        if user:
            if not user['is_approved']:
                flash('Your account is pending admin approval.', 'error')
                return redirect(url_for('login'))
            # If the browser cleared cookies (or the server restarted), the previous
            # DB session token cannot be presented anymore. Allow login by replacing
            # any prior DB sessions for this user.
            if has_active_db_session(user['id']):
                clear_db_session(user['id'])
            set_user_session(user)
            return redirect(url_for('user_dashboard'))
            
        flash('Invalid username or password.', 'error')
            
    # If it's a GET request and user is already logged in, send them home
    if 'user_id' in session:
        return redirect(url_for('index'))
        
    slots_left = max(0, ADMIN_LIMIT - get_admin_count())
    return render_template('login.html', admin_slots_left=slots_left, admin_count=get_admin_count(), admin_limit=ADMIN_LIMIT)

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        session.clear()
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        
        refresh_admin_cache()

        # If an account was deleted/disabled in the DB, do not allow config-based resurrection.
        conn = get_db()
        try:
            _init_disabled_accounts(conn)
            if is_account_disabled(conn, username):
                flash('This account was deleted/disabled.', 'error')
                return redirect(url_for('admin_login'))
        finally:
            conn.close()
        
        # --- Check 1: Super Admin (plaintext from .env) ---
        super_user = os.getenv('SUPER_ADMIN_USERNAME', '').strip()
        super_pass = os.getenv('SUPER_ADMIN_PASSWORD', '').strip()
        is_super = (super_user and super_pass and username == super_user and password == super_pass)
        
        # --- Check 2: Regular admin (from ADMIN_ACCOUNTS) ---
        admin_cfg = ADMIN_MAP.get(username)
        is_regular = (admin_cfg and password_matches(admin_cfg['password'], password)) if not is_super else False
        
        if is_super or is_regular:
            conn = get_db()
            admin_user = conn.execute(
                "SELECT * FROM users WHERE username=? AND role='admin'",
                (username,)
            ).fetchone()
            
            # Auto-create DB row if missing
            if not admin_user:
                display = 'Super Admin' if is_super else (admin_cfg['display_name'] if admin_cfg else username)
                pw_store = password if is_super else (admin_cfg['password'] if admin_cfg else password)
                conn.execute(
                    "INSERT INTO users (username, password, display_name, role, is_approved, is_super_admin) VALUES (?, ?, ?, 'admin', 1, ?)",
                    (username, pw_store, display, 1 if is_super else 0)
                )
                conn.commit()
                admin_user = conn.execute(
                    "SELECT * FROM users WHERE username=? AND role='admin'", (username,)
                ).fetchone()
            
            conn.close()
            
            if admin_user:
                session['user_id'] = admin_user['id']
                session['admin_id'] = admin_user['id']
                session['username'] = admin_user['username']
                session['display_name'] = admin_user['display_name'] or username
                session['role'] = 'admin'
                session['is_super_admin'] = bool(admin_user['is_super_admin'])
                flash(f"Welcome, {session['display_name']}!", 'success')
                return redirect(url_for('admin_dashboard'))
        
        flash('Invalid admin credentials.', 'error')
            
    # If it's a GET request and user is already logged in as admin, send them home
    if 'user_id' in session and session.get('role') == 'admin':
        return redirect(url_for('admin_dashboard'))
        
    slots_left = max(0, ADMIN_LIMIT - get_admin_count())
    return render_template('admin_login.html', admin_slots_left=slots_left, admin_count=get_admin_count(), admin_limit=ADMIN_LIMIT)

@app.route('/register-admin', methods=['GET', 'POST'])
def register_admin():
    slots_left = max(0, ADMIN_LIMIT - get_admin_count())
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()
        display_name = request.form.get('display_name', '').strip()
        if is_admin_limit_reached():
            flash('Admin limit reached (5/5).', 'error')
            return redirect(url_for('register_admin'))
        if not username or not display_name or len(password) < 6:
            flash('Validation failed: username, display name, password>=6 required.', 'error')
            return redirect(url_for('register_admin'))
        if password != confirm_password:
            flash('Validation failed: passwords do not match.', 'error')
            return redirect(url_for('register_admin'))
        conn = get_db()
        existing_user = conn.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone()
        if existing_user or username in ADMIN_MAP:
            # Allow re-creating a previously deleted/disabled admin username.
            try:
                _init_disabled_accounts(conn)
                if not is_account_disabled(conn, username):
                    conn.close()
                    flash('Duplicate username.', 'error')
                    return redirect(url_for('register_admin'))
            except Exception:
                conn.close()
                flash('Duplicate username.', 'error')
                return redirect(url_for('register_admin'))
        ok, err = add_admin_to_env(username, password, display_name)
        if not ok:
            conn.close()
            flash(err or 'Unable to save admin to .env.', 'error')
            return redirect(url_for('register_admin'))
        admin_cfg = ADMIN_MAP.get(username)
        conn.execute(
            "INSERT INTO users (username, password, display_name, role, is_approved) VALUES (?, ?, ?, 'admin', 1)",
            (username, admin_cfg['password'], display_name)
        )
        conn.commit()
        conn.close()
        flash('Admin account created successfully. Please sign in.', 'success')
        return redirect(url_for('admin_login'))
    return render_template('register_admin.html', admin_slots_left=slots_left, admin_count=get_admin_count(), admin_limit=ADMIN_LIMIT)

@app.route('/check-admin-slots')
def check_admin_slots():
    slots_left = max(0, ADMIN_LIMIT - get_admin_count())
    return jsonify({'available': slots_left > 0, 'slots_left': slots_left})

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        display_name = request.form.get('display_name', '').strip()
        username = request.form['username'].strip()
        password = request.form['password'].strip()
        
        if not username or not password or not display_name:
            flash('All fields are required.', 'error')
            return redirect(url_for('register'))
            
        conn = get_db()
        existing = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if existing:
            conn.close()
            flash('Username already exists.', 'error')
            return redirect(url_for('register'))
            
        conn.execute("INSERT INTO users (username, password, display_name, role, is_approved) VALUES (?, ?, ?, 'user', 0)",
                     (username, password, display_name))
        conn.commit()
        conn.close()
        flash('Registration successful! Please wait for admin approval.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    conn = get_db()
    user = conn.execute(
        "SELECT id, username, display_name, role, gmail FROM users WHERE id=?",
        (session['user_id'],)
    ).fetchone()
    if not user:
        conn.close()
        session.clear()
        flash('Profile not found. Please log in again.', 'error')
        return redirect(url_for('login'))
    if request.method == 'POST':
        display_name = request.form.get('display_name', '').strip()
        gmail = normalize_gmail(request.form.get('gmail', ''))
        if not display_name:
            conn.close()
            flash('Display name is required.', 'error')
            return redirect(url_for('profile'))
        if gmail and not is_valid_gmail(gmail):
            conn.close()
            flash("Couldn't find your Google Account", 'error')
            return redirect(url_for('profile'))

        if gmail:
            existing = conn.execute(
                "SELECT id FROM users WHERE gmail=? AND id<>?",
                (gmail, user['id'])
            ).fetchone()
            if existing:
                conn.close()
                flash('That Gmail is already used by another user.', 'error')
                return redirect(url_for('profile'))
        conn.execute(
            "UPDATE users SET display_name=?, gmail=?, gmail_verified=0 WHERE id=?",
            (display_name, gmail or None, user['id'])
        )
        conn.commit()
        conn.close()
        session['display_name'] = display_name
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'ok': True,
                'message': 'Profile updated.',
                'next_url': url_for('admin_dashboard' if session.get('role') == 'admin' else 'user_dashboard')
            })
        flash('Profile updated.', 'success')
        return redirect(url_for('admin_dashboard' if session.get('role') == 'admin' else 'user_dashboard'))
    conn.close()
    return render_template('profile.html', user=user, display_name=session.get('display_name') or user['display_name'] or user['username'])

@app.route('/logout')
def logout():
    if session.get('role') == 'user' and session.get('user_id'):
        clear_db_session(session['user_id'], session.get('session_token'))
    session.clear()
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))

@app.route('/delete-account', methods=['POST'])
def delete_account():
    if 'user_id' not in session:
        flash('Please log in to continue.', 'error')
        return redirect(url_for('login'))

    entered_username = (request.form.get('username') or '').strip()
    entered_password = (request.form.get('password') or '').strip()

    if not entered_username or not entered_password:
        flash('Username and password are required to delete your account.', 'error')
        return redirect(url_for('profile'))

    # Only allow deleting the currently logged-in user
    if entered_username != (session.get('username') or ''):
        flash('Username does not match the current account.', 'error')
        return redirect(url_for('profile'))

    conn = get_db()
    try:
        _init_disabled_accounts(conn)
        user = conn.execute(
            "SELECT id, username, password, role FROM users WHERE id=?",
            (session['user_id'],)
        ).fetchone()
        if not user:
            flash('Account not found.', 'error')
            return redirect(url_for('login'))

        if user['username'] != entered_username or not password_matches(user['password'], entered_password):
            flash('Invalid username or password. Account not deleted.', 'error')
            return redirect(url_for('profile'))

        if user.get('is_super_admin'):
            flash('Super Admin account cannot be deleted from the web UI.', 'error')
            return redirect(url_for('profile'))

        # Mark as disabled to prevent config-based resurrection (admins) and sample-user reseeding.
        disable_account(conn, user['username'])

        # Remove any active DB sessions, then delete user
        conn.execute("DELETE FROM sessions WHERE user_id=?", (user['id'],))
        conn.execute("DELETE FROM users WHERE id=?", (user['id'],))
        conn.commit()
    finally:
        conn.close()

    session.clear()
    flash('Account deleted successfully.', 'success')
    return redirect(url_for('login'))

# ─── ADMIN ROUTES ────────────────────────────────────────────────────────────

@app.route('/admin')
@admin_required
def admin_dashboard():
    conn = get_db()
    places = conn.execute("SELECT * FROM places ORDER BY name").fetchall()
    all_complaints = conn.execute('''
        SELECT c.*, p.name as place_name 
        FROM complaints c JOIN places p ON c.place_id = p.id
        ORDER BY c.created_at DESC
    ''').fetchall()
    active = [c for c in all_complaints if not c['is_completed']]
    
    # Enrich completed complaints with days_left until auto-delete
    done = []
    for c in all_complaints:
        if c['is_completed']:
            row = dict(c)
            if c['completed_at']:
                try:
                    comp_dt = datetime.strptime(c['completed_at'][:19], '%Y-%m-%d %H:%M:%S')
                    # Calculate days remaining until 7-day auto-expiry
                    row['days_left'] = max(0, 7 - (datetime.now() - comp_dt).days)
                except Exception:
                    row['days_left'] = None
            else:
                row['days_left'] = None
            done.append(row)
            
    stats = {
        'total': len(all_complaints), 
        'active': len(active), 
        'places': len(places), 
        'completed': len(done)
    }
    sync_status = get_sync_status_snapshot()
    ts_status   = timescale_db.get_ts_status()
    conn.close()
    return render_template(
        'admin_dashboard.html',
        places=places,
        active_complaints=active,
        completed_complaints=done,
        stats=stats,
        sync_status=sync_status,
        ts_status=ts_status,
        now=datetime.now().strftime('%Y-%m-%dT%H:%M'),
        display_name=session.get('display_name', session.get('username', 'Admin'))
    )

@app.route('/admin/add_complaint', methods=['POST'])
@admin_required
def add_complaint():
    debug_log = (os.getenv('APP_DEBUG_LOG', '0').strip().lower() in {'1', 'true', 'yes'})
    if debug_log:
        print(f"DEBUG: Form data: {request.form}")
    place_id = request.form.get('place_id')
    created_at = parse_datetime_input(request.form.get('created_at'))
    raw_batch = request.form.get('complaints_json', '').strip()
    note = request.form.get('note', '').strip()
    if debug_log:
        print(f"DEBUG: place_id={place_id}, created_at={created_at}, raw_batch={raw_batch}")

    complaints = []
    if raw_batch:
        try:
            parsed = json.loads(raw_batch)
        except json.JSONDecodeError:
            parsed = None

        if isinstance(parsed, list):
            complaints = [
                str(item).strip()
                for item in parsed
                if isinstance(item, str) and str(item).strip()
            ]
    elif note:
        complaints = [note]

    if not place_id or not created_at or not complaints:
        flash('Place, complaint list, and a valid complaint date are required.', 'error')
        return redirect(url_for('admin_dashboard'))

    if len(complaints) > 10:
        flash('You can submit a maximum of 10 complaints at once.', 'error')
        return redirect(url_for('admin_dashboard'))

    conn = get_db()
    try:
        inserted_ids = []
        creator = session.get('display_name') or session.get('username')
        for complaint_note in complaints:
            cursor = conn.execute(
                "INSERT INTO complaints (place_id, note, created_at, created_by) VALUES (?, ?, ?, ?) RETURNING id",
                (place_id, complaint_note, created_at, creator)
            )
            inserted = cursor.fetchone()
            inserted_ids.append(inserted["id"] if inserted else None)
        conn.commit()

        # ── Archive to PostgreSQL log (non-fatal) ───────────────────────────
        try:
            place_row = conn.execute("SELECT name FROM places WHERE id=?", (place_id,)).fetchone()
            place_name = place_row['name'] if place_row else 'Unknown'
            
            archive_payloads = []
            for i, cid in enumerate(inserted_ids):
                archive_payloads.append({
                    'complaint_id': str(cid),
                    'completion_date': None, # Newly submitted
                    'place': place_name,
                    'complaint_note': complaints[i],
                    'created_at': created_at,
                })
            timescale_db.bulk_archive_completed_complaints(archive_payloads)
        except Exception as e:
            print(f"[timescale_db] Submission archive failed: {e}")

        flash(f'{len(complaints)} complaint(s) added and logged!', 'success')
    except Exception as e:
        conn.rollback()
        flash(f'Unable to save the complaint batch: {e}', 'error')
    finally:
        conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/update_complaint/<int:cid>', methods=['POST'])
@admin_required
def update_complaint(cid):
    place_id = request.form.get('place_id')
    note = request.form.get('note', '').strip()
    created_at = parse_datetime_input(request.form.get('created_at'))

    if not place_id or not note or not created_at:
        flash('Place, note, and a valid complaint date are required.', 'error')
        return redirect(url_for('admin_dashboard'))

    conn = get_db()
    conn.execute(
        "UPDATE complaints SET place_id=?, note=?, created_at=? WHERE id=?",
        (place_id, note, created_at, cid)
    )
    conn.commit()
    conn.close()
    flash('Complaint updated.', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/add_place', methods=['POST'])
@admin_required
def add_place():
    name = request.form.get('place_name', '').strip()
    if name:
        conn = get_db(); 
        try:
            conn.execute("INSERT INTO places (name) VALUES (?)", (name,)); conn.commit()
        except: flash('Place exists.', 'error')
        conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete_complaint/<int:cid>', methods=['POST'])
@super_admin_required
@admin_required
def delete_complaint(cid):
    conn = get_db(); conn.execute("DELETE FROM complaints WHERE id=?", (cid,)); conn.commit(); conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/delete_place/<int:pid>', methods=['POST'])
@super_admin_required
@admin_required
def delete_place(pid):
    conn = get_db()
    conn.execute("DELETE FROM complaints WHERE place_id=?", (pid,))
    conn.execute("DELETE FROM places WHERE id=?", (pid,))
    conn.commit(); conn.close()
    return redirect(url_for('admin_dashboard'))

# ─── USER ROUTES ─────────────────────────────────────────────────────────────

@app.route('/user')
@login_required
def user_dashboard():
    if session.get('role') == 'admin': return redirect(url_for('admin_dashboard'))
    conn = get_db()
    places = conn.execute("SELECT * FROM places ORDER BY name").fetchall()
    place_data = []
    for p in places:
        count = conn.execute("SELECT COUNT(*) as cnt FROM complaints WHERE place_id=? AND is_completed=0", (p['id'],)).fetchone()['cnt']
        if count > 0: place_data.append({'id': p['id'], 'name': p['name'], 'count': count})
    conn.close()
    return render_template('user_dashboard.html', places=place_data, display_name=session.get('display_name') or session.get('username'))

@app.route('/user/place/<int:place_id>')
@login_required
def view_place(place_id):
    if session.get('role') == 'admin': return redirect(url_for('admin_dashboard'))
    conn = get_db()
    place = conn.execute("SELECT * FROM places WHERE id=?", (place_id,)).fetchone()
    complaints = conn.execute("SELECT * FROM complaints WHERE place_id=? ORDER BY created_at DESC", (place_id,)).fetchall()
    conn.execute("UPDATE complaints SET is_read=1 WHERE place_id=?", (place_id,))
    conn.commit(); conn.close()
    pending = [c for c in complaints if not c['is_completed']]
    finished = [c for c in complaints if c['is_completed']]
    return render_template(
        'place_complaints.html',
        place=place,
        pending_list=pending,
        finished_list=finished,
        total=len(complaints),
        completed=len(finished),
        display_name=session.get('display_name') or session.get('username')
    )

#--------------------------------------------------------------------------

#--------------------------------------------------------------------------

@app.route('/user/complete_complaint/<int:cid>', methods=['POST'])
@login_required
def complete_complaint(cid):
    if session.get('role') == 'admin': return redirect(url_for('admin_dashboard'))
    conn = get_db()

    # Fetch full row before marking done (needed for archive payload)
    complaint_row = conn.execute(
        '''
        SELECT c.*, p.name AS place_name
        FROM complaints c
        JOIN places p ON c.place_id = p.id
        WHERE c.id = ?
        ''',
        (cid,)
    ).fetchone()

    if complaint_row:
        completed_at_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        finisher_name = session.get('display_name') or session.get('username') or ''
        conn.execute(
            "UPDATE complaints SET is_completed=1, completed_at=?, completed_by=? WHERE id=?",
            (completed_at_str, finisher_name, cid)
        )
        conn.commit()

        # ── Archive to TimescaleDB (non-fatal) ───────────────────────────────
        ts_payload = {
            'complaint_id':          str(cid),
            'completion_date':       completed_at_str,
            'place':                 complaint_row['place_name'] or '',
            'complaint_note':        complaint_row['note'] or '',
            'finisher_profile_name': finisher_name,
            'finisher_user_id':      session.get('user_id'),
            'created_at':            complaint_row['created_at'] or '',
        }
        ok, ts_err = timescale_db.archive_completed_complaint(ts_payload)
        if not ok:
            print(f"[timescale_db] Archive warning for complaint #{cid}: {ts_err}")

    conn.close()
    return redirect(url_for('view_place', place_id=complaint_row['place_id'] if complaint_row else 0))


# ─── DB ADMIN ROUTES ─────────────────────────────────────────────────────────

@app.route('/db-admin')
@super_admin_required
@admin_required
def db_admin():
    conn = get_db()
    users = conn.execute('''
        SELECT *
        FROM users
        ORDER BY
            CASE
                WHEN role = 'user' AND is_approved = 0 THEN 0
                ELSE 1
            END,
            CASE
                WHEN role = 'user' AND is_approved = 0 THEN id
            END DESC,
            id DESC
    ''').fetchall()
    places = conn.execute('''
        SELECT p.*, COUNT(c.id) AS complaint_count
        FROM places p
        LEFT JOIN complaints c ON c.place_id = p.id
        GROUP BY p.id
        ORDER BY p.id
    ''').fetchall()
    complaints = conn.execute(
        '''
        SELECT c.*, p.name as place_name
        FROM complaints c
        JOIN places p ON c.place_id = p.id
        ORDER BY c.is_completed ASC, c.created_at DESC
        '''
    ).fetchall()
    pending_count = sum(1 for c in complaints if not c['is_completed'])
    completed_count = len(complaints) - pending_count
    sync_status = get_sync_status_snapshot()
    conn.close()
    return render_template(
        'db_admin.html',
        users=users,
        places=places,
        complaints=complaints,
        sync_status=sync_status,
        pending_count=pending_count,
        completed_count=completed_count
    )

@app.route('/admin/retry-sync', methods=['POST'])
@admin_required
def admin_retry_sync():
    synced, failed = retry_sync_queue(run_all=True)
    flash(f'{synced} items synced, {failed} failed', 'success' if failed == 0 else 'error')
    return redirect(request.referrer or url_for('db_admin'))

@app.route('/admin/sync-status')
@admin_required
def admin_sync_status():
    return jsonify(get_sync_status_snapshot())

@app.route('/admin/sync-archive', methods=['POST'])
@admin_required
def admin_sync_archive():
    """Manually trigger a sync of all complaints to the PostgreSQL archive."""
    synced, failed = sync_all_to_archive()
    if synced > 0:
        flash(f'Successfully archived {synced} complaints to PostgreSQL.', 'success')
    elif failed > 0:
        flash(f'Failed to archive {failed} complaints. Check PostgreSQL connection.', 'error')
    else:
        flash('No complaints found to archive.', 'info')
    return redirect(url_for('db_admin'))

@app.route('/db-admin/delete/complaint/<int:cid>', methods=['POST'])
@super_admin_required
@admin_required
def db_admin_delete_complaint(cid):
    conn = get_db()
    conn.execute("DELETE FROM complaints WHERE id=?", (cid,))
    conn.commit()
    conn.close()
    flash('Complaint deleted.', 'success')
    return redirect(url_for('db_admin'))

@app.route('/db-admin/delete/place/<int:pid>', methods=['POST'])
@super_admin_required
@admin_required
def db_admin_delete_place(pid):
    conn = get_db()
    conn.execute("DELETE FROM complaints WHERE place_id=?", (pid,))
    conn.execute("DELETE FROM places WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    flash('Place and related complaints deleted.', 'success')
    return redirect(url_for('db_admin'))

@app.route('/db-admin/delete/user/<int:uid>', methods=['POST'])
@super_admin_required
@admin_required
def db_admin_delete_user(uid):
    conn = get_db()
    _init_disabled_accounts(conn)
    user = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()

    if user and user['role'] == 'admin' and not session.get('is_super_admin'):
        flash('Only a Super Admin can delete other administrative accounts.', 'error')
    else:
        # Prevent super admin from deleting themselves (optional, but safer)
        if user and user['username'] == session.get('username'):
            flash('You cannot delete your own account while logged in.', 'error')
        else:
            if user and user.get('is_super_admin'):
                flash('Super Admin account cannot be deleted.', 'error')
                conn.close()
                return redirect(url_for('db_admin'))

            if user:
                disable_account(conn, user['username'])
            cur = conn.execute("DELETE FROM users WHERE id=?", (uid,))
            conn.commit()
            still = conn.execute("SELECT 1 AS ok FROM users WHERE id=?", (uid,)).fetchone()
            if still:
                flash(f"Delete did not persist. DB: {_db_diagnostics(conn)}", 'error')
            elif getattr(cur, 'rowcount', None) == 0:
                flash('No matching account found to delete (already removed?).', 'error')
            else:
                flash('Account deleted.', 'success')

    conn.close()
    return redirect(url_for('db_admin'))

@app.route('/db-admin/approve/user/<int:uid>', methods=['POST'])
@super_admin_required
@admin_required
def db_admin_approve_user(uid):
    conn = get_db(); conn.execute("UPDATE users SET is_approved=1 WHERE id=?", (uid,)); conn.commit(); conn.close()
    return redirect(url_for('db_admin'))

@app.route('/db-admin/bulk-delete/<string:table>', methods=['POST'])
@super_admin_required
@admin_required
def db_admin_bulk_delete(table):
    raw_ids = request.form.get('ids', '')
    ids = [int(part) for part in raw_ids.split(',') if part.strip().isdigit()]

    if not ids:
        flash('No valid records selected for deletion.', 'error')
        return redirect(url_for('db_admin'))

    placeholders = ','.join('?' for _ in ids)
    conn = get_db()

    if table == 'complaints':
        conn.execute(f"DELETE FROM complaints WHERE id IN ({placeholders})", ids)
        flash(f'Deleted {len(ids)} complaint(s).', 'success')
    elif table == 'places':
        conn.execute(f"DELETE FROM complaints WHERE place_id IN ({placeholders})", ids)
        conn.execute(f"DELETE FROM places WHERE id IN ({placeholders})", ids)
        flash(f'Deleted {len(ids)} place(s) and related complaints.', 'success')
    elif table == 'users':
        protected_ids = set()
        if not session.get('is_super_admin'):
            protected_ids = {
                row['id']
                for row in conn.execute(
                    f"SELECT id FROM users WHERE id IN ({placeholders}) AND role='admin'",
                    ids
                ).fetchall()
            }
        
        # Also protect self
        current_user_id = session.get('user_id')
        if current_user_id in ids:
            protected_ids.add(current_user_id)

        deletable_ids = [uid for uid in ids if uid not in protected_ids]

        if deletable_ids:
            user_placeholders = ','.join('?' for _ in deletable_ids)
            conn.execute(f"DELETE FROM users WHERE id IN ({user_placeholders})", deletable_ids)

        if protected_ids:
            flash('Admin users were skipped during bulk delete.', 'error')

        flash(f'Deleted {len(deletable_ids)} user(s).', 'success')
    else:
        conn.close()
        flash('Invalid bulk delete target.', 'error')
        return redirect(url_for('db_admin'))

    conn.commit()
    conn.close()
    return redirect(url_for('db_admin'))


# ─── OLD LOGS (TimescaleDB) ROUTES ──────────────────────────────────────────

@app.route('/admin/old-logs')
@admin_required
def old_logs():
    """Browse archived completed complaints stored in TimescaleDB."""
    page      = max(1, int(request.args.get('page', 1)))
    per_page  = 20
    date_from = request.args.get('date_from', '').strip()
    date_to   = request.args.get('date_to', '').strip()
    place     = request.args.get('place', '').strip()
    finisher  = request.args.get('finisher', '').strip()
    search    = request.args.get('search', '').strip()

    logs, total, ts_error = timescale_db.get_old_logs(
        page=page,
        per_page=per_page,
        date_from=date_from or None,
        date_to=date_to or None,
        place=place or None,
        finisher=finisher or None,
        search=search or None,
    )
    stats = timescale_db.get_old_logs_stats()
    total_pages = max(1, (total + per_page - 1) // per_page)

    return render_template(
        'old_logs.html',
        logs=logs,
        total=total,
        page=page,
        per_page=per_page,
        total_pages=total_pages,
        stats=stats,
        ts_error=ts_error,
        f_date_from=date_from,
        f_date_to=date_to,
        f_place=place,
        f_finisher=finisher,
        f_search=search,
        display_name=session.get('display_name', session.get('username', 'Admin'))
    )


@app.route('/admin/old-logs/data')
@admin_required
def old_logs_data():
    """JSON endpoint — paginated log data."""
    page      = max(1, int(request.args.get('page', 1)))
    per_page  = int(request.args.get('per_page', 20))
    date_from = request.args.get('date_from', '').strip() or None
    date_to   = request.args.get('date_to', '').strip() or None
    place     = request.args.get('place', '').strip() or None
    finisher  = request.args.get('finisher', '').strip() or None
    search    = request.args.get('search', '').strip() or None

    logs, total, error = timescale_db.get_old_logs(
        page=page, per_page=per_page,
        date_from=date_from, date_to=date_to,
        place=place, finisher=finisher, search=search
    )
    return jsonify({
        'logs': logs,
        'total': total,
        'page': page,
        'per_page': per_page,
        'total_pages': max(1, (total + per_page - 1) // per_page),
        'error': error,
    })


# ─── LOG PREVIOUS ROUTE ─────────────────────────────────────────────────────

@app.route('/previous_logs')
@admin_required
def previous_logs():
    sheets_data = {}
    sheet_names = []

    return render_template(
        'previous_logs.html',
        sheets_data=json.dumps(sheets_data),
        sheet_names=sheet_names,
        sync_status=get_sync_status_snapshot()
    )



def bootstrap_runtime():
    """Initialize local storage and background retry worker."""
    if _env_bool('EMBEDDED_PG', False):
        try:
            from embedded_pg import start_pg
            start_pg()
        except Exception as exc:
            print(f"FATAL: Embedded PostgreSQL failed to start: {exc}")
            raise
    init_db()
    start_sync_retry_worker()
    
    # Auto-sync existing complaints on startup
    threading.Thread(target=sync_all_to_archive, daemon=True).start()


def _db_diagnostics(conn):
    """
    Return high-signal info to confirm which DB instance is in use.
    This avoids 'deleted but still there' confusion when multiple DBs exist.
    """
    backend = getattr(conn, 'backend', 'postgres')
    info = {'backend': backend}
    if backend == 'sqlite':
        # If SQLITE_PATH isn't set, we default to ./data/complaints.db
        info['sqlite_path'] = (SQLITE_PATH or os.path.join('data', 'complaints.db'))
        return info

    try:
        row = conn.execute("SELECT current_database() AS db, inet_server_addr() AS addr, inet_server_port() AS port").fetchone()
        if row:
            info.update({'db': row.get('db'), 'addr': row.get('addr'), 'port': row.get('port')})
    except Exception:
        pass
    try:
        row = conn.execute("SHOW data_directory").fetchone()
        if row:
            # psycopg2 RealDictCursor returns {'data_directory': '...'}
            info['data_directory'] = next(iter(row.values()))
    except Exception:
        pass
    return info


@app.route('/debug/db')
@super_admin_required
@admin_required
def debug_db():
    conn = get_db()
    try:
        return jsonify(_db_diagnostics(conn))
    finally:
        conn.close()



# Global Error Handlers (Prevents tracebacks in production)
@app.errorhandler(500)
def handle_500(e):
    return render_template('error.html', error="An internal server error occurred."), 500

@app.errorhandler(404)
def handle_404(e):
    return render_template('error.html', error="The requested page was not found."), 404

# Removed app.run() block. Use a WSGI server like Gunicorn or Waitress.
if __name__ == '__main__':
    print("FATAL: Do not run app.py directly. Use Gunicorn or Waitress.")
    sys.exit(1)


