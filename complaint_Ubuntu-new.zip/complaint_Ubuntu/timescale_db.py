"""
timescale_db.py — ComplaintDesk
All PostgreSQL / TimescaleDB interactions are isolated here.

Graceful degradation: every public function catches exceptions so that
the main Flask app keeps running even when Postgres is unavailable.
""" 

import os
import json
import traceback
import platform
import socket
import subprocess
import time
from datetime import datetime
from urllib.parse import urlparse
from typing import List, Dict

# psycopg2 is optional; app degrades gracefully if not installed.
try:
    import psycopg2
    import psycopg2.extras
    _PSYCOPG2_AVAILABLE = True
except ImportError:
    _PSYCOPG2_AVAILABLE = False

# ──────────────────────────────────────────────────────────────────────────────
# Connection
# ──────────────────────────────────────────────────────────────────────────────

_DEFAULT_WINDOWS_SERVICES = [
    "postgresql-x64-17",
    "postgresql-x64-16",
    "postgresql-x64-15",
    "postgresql-x64-14",
    "postgresql-x64-13",
    "postgresql",
]

def _extract_host_port_from_url():
    """Return (host, port) parsed from TIMESCALE_URL, with safe defaults."""
    url = os.getenv("TIMESCALE_URL", "").strip()
    if not url:
        return "localhost", 5432
    try:
        parsed = urlparse(url)
        host = parsed.hostname or "localhost"
        port = parsed.port or 5432
        return host, port
    except Exception:
        return "localhost", 5432

def _port_accepting_connections(host, port):
    try:
        with socket.create_connection((host, int(port)), timeout=1.5):
            return True
    except Exception:
        return False

def _wait_for_port(host, port, timeout_seconds=15):
    deadline = time.time() + max(1, int(timeout_seconds))
    while time.time() < deadline:
        if _port_accepting_connections(host, port):
            return True
        time.sleep(1)
    return False

def _list_candidate_services():
    configured = os.getenv("POSTGRES_SERVICE_NAME", "").strip()
    if configured:
        return [configured]
    names = _DEFAULT_WINDOWS_SERVICES[:]
    discovered = []
    probe = _run_powershell(
        "Get-Service | Where-Object { $_.Name -match 'postgres|timescaledb' -or $_.DisplayName -match 'postgres|timescaledb' } | "
        "ForEach-Object { $_.Name }"
    )
    if probe.returncode == 0:
        discovered = [line.strip() for line in (probe.stdout or "").splitlines() if line.strip()]
    for name in discovered:
        if name not in names:
            names.append(name)
    return names

def _run_powershell(script):
    return subprocess.run(
        ["powershell", "-NoProfile", "-Command", script],
        capture_output=True,
        text=True,
        check=False,
    )

def try_auto_start_postgres():
    """
    Attempt to auto-start PostgreSQL service on Windows.
    Returns a dict with keys: started, attempted, service, message.
    """
    host, port = _extract_host_port_from_url()
    result = {
        "started": False,
        "attempted": False,
        "service": None,
        "message": "",
    }

    if platform.system().lower() != "windows":
        result["message"] = "Auto-start skipped (non-Windows platform)."
        return result

    if _port_accepting_connections(host, port):
        result["started"] = True
        result["message"] = f"PostgreSQL already reachable at {host}:{port}."
        return result

    for service_name in _list_candidate_services():
        check = _run_powershell(
            f"$svc = Get-Service -Name '{service_name}' -ErrorAction SilentlyContinue; "
            "if ($svc) { Write-Output $svc.Status }"
        )
        status = (check.stdout or "").strip().lower()
        if not status:
            continue

        result["attempted"] = True
        result["service"] = service_name

        if status != "running":
            start = _run_powershell(
                f"Start-Service -Name '{service_name}' -ErrorAction Stop; "
                f"Write-Output 'started:{service_name}'"
            )
            if start.returncode != 0:
                err = (start.stderr or start.stdout or "").strip()
                if "Cannot open" in err or "Access is denied" in err:
                    result["message"] = (
                        f"Service '{service_name}' found, but permission denied while starting it."
                    )
                else:
                    result["message"] = (
                        f"Service '{service_name}' found, but failed to start: {err or 'unknown error'}"
                    )
                return result

        if _wait_for_port(host, port, timeout_seconds=20):
            result["started"] = True
            result["message"] = (
                f"Service '{service_name}' is running and PostgreSQL is reachable at {host}:{port}."
            )
            return result

        result["message"] = (
            f"Service '{service_name}' started, but PostgreSQL is still unreachable at {host}:{port}."
        )
        return result

    result["message"] = (
        "No PostgreSQL Windows service found. Install PostgreSQL/TimescaleDB or set POSTGRES_SERVICE_NAME in .env."
    )
    return result

def get_ts_conn():
    """
    Return a new psycopg2 connection using TIMESCALE_URL from the environment.
    Raises ConnectionError if Postgres is unavailable or the env-var is unset.
    """
    if not _PSYCOPG2_AVAILABLE:
        raise ConnectionError("psycopg2 is not installed. Run: pip install psycopg2-binary")

    url = os.getenv("TIMESCALE_URL", "").strip()
    if not url:
        raise ConnectionError(
            "TIMESCALE_URL is not set in .env. "
            "Example: postgresql://postgres:password@localhost:5432/complaint_logs"
        )
    return psycopg2.connect(url, cursor_factory=psycopg2.extras.RealDictCursor)


def _conn_ok():
    """Quick check — returns True if a connection can be established."""
    try:
        conn = get_ts_conn()
        conn.close()
        return True
    except Exception:
        return False


# ──────────────────────────────────────────────────────────────────────────────
# Schema initialisation (called once at startup)
# ──────────────────────────────────────────────────────────────────────────────

_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS complaint_log (
    id                    BIGSERIAL PRIMARY KEY,
    complaint_id          VARCHAR(50)  UNIQUE NOT NULL,
    completion_date       TIMESTAMPTZ,
    place                 VARCHAR(200),
    complaint_note        TEXT,
    finisher_profile_name VARCHAR(100),
    finisher_user_id      BIGINT,
    resolution_time_hours FLOAT,
    satisfaction_score    INT CHECK (satisfaction_score BETWEEN 1 AND 5),
    attachments           JSONB,
    created_at            TIMESTAMPTZ  DEFAULT NOW(),
    updated_at            TIMESTAMPTZ  DEFAULT NOW()
);
"""

_INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_ts_completion_date  ON complaint_log (completion_date DESC);
CREATE INDEX IF NOT EXISTS idx_ts_finisher_profile ON complaint_log (finisher_profile_name);
CREATE INDEX IF NOT EXISTS idx_ts_place            ON complaint_log (place);
CREATE INDEX IF NOT EXISTS idx_ts_complaint_id     ON complaint_log (complaint_id);
"""

_COMPRESS_SQL = """
ALTER TABLE complaint_log SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'finisher_profile_name',
    timescaledb.compress_orderby   = 'completion_date DESC'
);

SELECT add_compression_policy(
    'complaint_log',
    INTERVAL '180 days',
    if_not_exists => TRUE
);
"""


def init_timescale_db():
    """
    Initialise the database schema. 
    Gracefully handles missing TimescaleDB extension by falling back to plain PostgreSQL tables.
    """
    try:
        conn = get_ts_conn()
        
        # 1. Check if extension is actually available in the PG installation
        # This prevents transaction aborts if we try to CREATE EXTENSION and it fails.
        has_extension = False
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM pg_available_extensions WHERE name = 'timescaledb';")
                if cur.fetchone():
                    try:
                        cur.execute("CREATE EXTENSION IF NOT EXISTS timescaledb;")
                        conn.commit()
                        has_extension = True
                        print("[timescale_db] Extension 'timescaledb' enabled.")
                    except Exception as e:
                        conn.rollback()
                        print(f"[timescale_db] Found extension but failed to enable: {e}")
                else:
                    print("[timescale_db] Extension 'timescaledb' not found in available extensions.")
        except Exception as e:
            print(f"[timescale_db] Error checking extensions: {e}")

        # 2. Create the core table and indexes
        with conn:
            with conn.cursor() as cur:
                # Core table (Plain SQL)
                cur.execute(_TABLE_SQL)

                # Convert to hypertable if extension exists
                if has_extension:
                    try:
                        cur.execute("""
                            SELECT create_hypertable(
                                'complaint_log',
                                'created_at',
                                chunk_time_interval => INTERVAL '30 days',
                                if_not_exists       => TRUE
                            );
                        """)
                    except Exception as e:
                        print(f"[timescale_db] Hypertable conversion failed: {e}")
                else:
                    print("[timescale_db] Skipping hypertable conversion (plain table used).")

                # Create standard indexes
                cur.execute(_INDEX_SQL)

        # 3. Try compression policy if extension exists
        if has_extension:
            try:
                with conn:
                    with conn.cursor() as cur:
                        cur.execute(_COMPRESS_SQL)
            except Exception as ce:
                print(f"[timescale_db] Compression policy skipped: {ce}")
        
        conn.close()
        print("[timescale_db] Schema initialised successfully (Plain/Timescale handled).")
        return True, None
    except Exception as exc:
        print(f"[timescale_db] init_timescale_db failed: {exc}")
        return False, str(exc)


# ──────────────────────────────────────────────────────────────────────────────
# Archive a completed complaint
# ──────────────────────────────────────────────────────────────────────────────

_UPSERT_SQL = """
INSERT INTO complaint_log (
    complaint_id,
    completion_date,
    place,
    complaint_note,
    finisher_profile_name,
    finisher_user_id,
    resolution_time_hours,
    attachments,
    updated_at
) VALUES (
    %(complaint_id)s,
    %(completion_date)s,
    %(place)s,
    %(complaint_note)s,
    %(finisher_profile_name)s,
    %(finisher_user_id)s,
    %(resolution_time_hours)s,
    %(attachments)s,
    NOW()
)
ON CONFLICT (complaint_id) DO UPDATE SET
    completion_date       = COALESCE(EXCLUDED.completion_date, complaint_log.completion_date),
    place                 = EXCLUDED.place,
    complaint_note        = EXCLUDED.complaint_note,
    finisher_profile_name = COALESCE(EXCLUDED.finisher_profile_name, complaint_log.finisher_profile_name),
    finisher_user_id      = COALESCE(EXCLUDED.finisher_user_id, complaint_log.finisher_user_id),
    resolution_time_hours = COALESCE(EXCLUDED.resolution_time_hours, complaint_log.resolution_time_hours),
    attachments           = EXCLUDED.attachments,
    updated_at            = NOW();
"""


def _parse_dt(value):
    """Parse a stored SQLite datetime string into a Python datetime (or None)."""
    if not value:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M'):
        try:
            return datetime.strptime(str(value)[:19], fmt)
        except ValueError:
            continue
    return None


def _resolution_hours(created_at_str, completed_at_str):
    """Compute hours between creation and completion; returns None if either is missing."""
    created = _parse_dt(created_at_str)
    completed = _parse_dt(completed_at_str)
    if created and completed:
        delta = completed - created
        return round(delta.total_seconds() / 3600, 2)
    return None


def archive_completed_complaint(payload: dict):
    """
    Upsert one completed complaint into TimescaleDB.
    Returns (True, None) on success or (False, error_message) on failure.
    """
    return bulk_archive_completed_complaints([payload])


def bulk_archive_completed_complaints(payloads: List[Dict]):
    """
    Upsert multiple completed complaints into TimescaleDB efficiently.
    Returns (True, None) if all (or some) were archived, or (False, error) if connection failed.
    """
    if not payloads:
        return True, None
    try:
        conn = get_ts_conn()
        with conn:
            with conn.cursor() as cur:
                for payload in payloads:
                    record = {
                        "complaint_id":          str(payload.get("complaint_id", "")),
                        "completion_date":       _parse_dt(payload.get("completion_date"))
                                                 or _parse_dt(payload.get("completed_at"))
                                                 or datetime.utcnow(),
                        "place":                 (payload.get("place") or "")[:200],
                        "complaint_note":        payload.get("complaint_note") or payload.get("note") or "",
                        "finisher_profile_name": (payload.get("finisher_profile_name")
                                                  or payload.get("completed_by") or "")[:100],
                        "finisher_user_id":      payload.get("finisher_user_id"),
                        "resolution_time_hours": _resolution_hours(
                            payload.get("created_at"),
                            payload.get("completion_date") or payload.get("completed_at")
                        ),
                        "attachments":           json.dumps(payload.get("attachments")) if payload.get("attachments") else None,
                    }
                    cur.execute(_UPSERT_SQL, record)
        conn.close()
        return True, None
    except Exception as exc:
        traceback.print_exc()
        print(f"[timescale_db] bulk_archive failed: {exc}")
        return False, str(exc)


# ──────────────────────────────────────────────────────────────────────────────
# Query — paginated log browser
# ──────────────────────────────────────────────────────────────────────────────

def get_old_logs(
    page: int = 1,
    per_page: int = 20,
    date_from: str = None,
    date_to: str = None,
    place: str = None,
    finisher: str = None,
    search: str = None,
):
    """
    Return paginated complaint_log rows plus total count.

    Returns: (rows: list[dict], total: int, error: str|None)
    """
    try:
        conn = get_ts_conn()
        conditions = []
        params = []

        if date_from:
            conditions.append("completion_date >= %s")
            params.append(date_from)
        if date_to:
            conditions.append("completion_date <= %s")
            params.append(date_to + " 23:59:59")
        if place:
            conditions.append("place ILIKE %s")
            params.append(f"%{place}%")
        if finisher:
            conditions.append("finisher_profile_name ILIKE %s")
            params.append(f"%{finisher}%")
        if search:
            conditions.append("(complaint_note ILIKE %s OR place ILIKE %s OR finisher_profile_name ILIKE %s)")
            params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])

        where_clause = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        # Total count
        count_sql = f"SELECT COUNT(*) AS cnt FROM complaint_log {where_clause}"
        # Data query
        offset = (page - 1) * per_page
        data_sql = f"""
            SELECT
                id,
                complaint_id,
                completion_date AT TIME ZONE 'UTC' AS completion_date,
                place,
                complaint_note,
                finisher_profile_name,
                resolution_time_hours,
                satisfaction_score,
                created_at AT TIME ZONE 'UTC' AS created_at
            FROM complaint_log
            {where_clause}
            ORDER BY completion_date DESC
            LIMIT %s OFFSET %s
        """
        with conn.cursor() as cur:
            cur.execute(count_sql, params)
            total = cur.fetchone()["cnt"]

            cur.execute(data_sql, params + [per_page, offset])
            rows = [dict(r) for r in cur.fetchall()]

        conn.close()
        # Serialise datetime objects to strings for Jinja
        for row in rows:
            for key in ("completion_date", "created_at"):
                if row.get(key) and hasattr(row[key], "strftime"):
                    row[key] = row[key].strftime("%Y-%m-%d %H:%M")
        return rows, int(total), None
    except Exception as exc:
        print(f"[timescale_db] get_old_logs failed: {exc}")
        return [], 0, str(exc)


# ──────────────────────────────────────────────────────────────────────────────
# Stats for dashboard header
# ──────────────────────────────────────────────────────────────────────────────

def get_old_logs_stats():
    """
    Return aggregate statistics about the archive.
    Returns a dict (all values default to 0 / [] on failure).
    """
    default = {
        "total": 0,
        "last_30_days": 0,
        "unique_places": 0,
        "unique_finishers": 0,
        "top_places": [],
        "top_finishers": [],
        "connected": False,
        "error": None,
    }
    try:
        conn = get_ts_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS cnt FROM complaint_log")
            default["total"] = int(cur.fetchone()["cnt"] or 0)

            cur.execute(
                "SELECT COUNT(*) AS cnt FROM complaint_log "
                "WHERE completion_date >= NOW() - INTERVAL '30 days'"
            )
            default["last_30_days"] = int(cur.fetchone()["cnt"] or 0)

            cur.execute("SELECT COUNT(DISTINCT place) AS cnt FROM complaint_log WHERE place IS NOT NULL")
            default["unique_places"] = int(cur.fetchone()["cnt"] or 0)

            cur.execute(
                "SELECT COUNT(DISTINCT finisher_profile_name) AS cnt "
                "FROM complaint_log WHERE finisher_profile_name IS NOT NULL"
            )
            default["unique_finishers"] = int(cur.fetchone()["cnt"] or 0)

            cur.execute(
                "SELECT place, COUNT(*) AS cnt FROM complaint_log "
                "WHERE place IS NOT NULL GROUP BY place ORDER BY cnt DESC LIMIT 5"
            )
            default["top_places"] = [dict(r) for r in cur.fetchall()]

            cur.execute(
                "SELECT finisher_profile_name, COUNT(*) AS cnt FROM complaint_log "
                "WHERE finisher_profile_name IS NOT NULL "
                "GROUP BY finisher_profile_name ORDER BY cnt DESC LIMIT 5"
            )
            default["top_finishers"] = [dict(r) for r in cur.fetchall()]

        conn.close()
        default["connected"] = True
        return default
    except Exception as exc:
        default["error"] = str(exc)
        print(f"[timescale_db] get_old_logs_stats failed: {exc}")
        return default


def get_ts_status():
    """
    Lightweight connectivity check for the admin dashboard badge.
    Returns dict: {connected: bool, total_archived: int}
    """
    try:
        conn = get_ts_conn()
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS cnt FROM complaint_log")
            total = int(cur.fetchone()["cnt"] or 0)
        conn.close()
        return {"connected": True, "total_archived": total}
    except Exception:
        return {"connected": False, "total_archived": 0}
