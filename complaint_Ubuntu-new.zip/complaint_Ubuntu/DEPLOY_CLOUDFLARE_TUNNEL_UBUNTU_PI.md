# Cloudflare Tunnel (Ubuntu / Raspberry Pi) migration notes

Your repo already includes a Pi-friendly app service (`complaintdesk.service`) that runs Gunicorn via systemd.

The Cloudflare Tunnel side is similar: install `cloudflared`, create the tunnel + DNS route once, then run it under systemd so it survives reboots and reconnects automatically.

## 1) Install cloudflared

On Raspberry Pi OS / Ubuntu:

```bash
sudo apt-get update
sudo apt-get install -y cloudflared
cloudflared --version
```

If your distro repository doesn’t have a recent `cloudflared`, install via Cloudflare’s package instructions for your OS/arch.

## 2) Authenticate + create the tunnel (one-time)

```bash
cloudflared tunnel login
cloudflared tunnel create complaintdesk
cloudflared tunnel route dns complaintdesk complaintdesk.example.com
cloudflared tunnel list
```

## 3) Create `/etc/cloudflared/config.yml`

```bash
sudo mkdir -p /etc/cloudflared
sudo nano /etc/cloudflared/config.yml
```

Example config:

```yaml
tunnel: <TUNNEL-UUID-HERE>
credentials-file: /etc/cloudflared/<TUNNEL-UUID-HERE>.json

ingress:
  - hostname: complaintdesk.example.com
    service: http://127.0.0.1:5050
  - service: http_status:404
```

Move the tunnel credentials JSON into `/etc/cloudflared/` and lock it down:

```bash
sudo mv ~/.cloudflared/<TUNNEL-UUID-HERE>.json /etc/cloudflared/
sudo chown root:root /etc/cloudflared/<TUNNEL-UUID-HERE>.json /etc/cloudflared/config.yml
sudo chmod 600 /etc/cloudflared/<TUNNEL-UUID-HERE>.json /etc/cloudflared/config.yml
```

## 4) Enable cloudflared as a system service

```bash
sudo cloudflared service install
sudo systemctl enable --now cloudflared
sudo systemctl status cloudflared --no-pager
```

Logs:

```bash
journalctl -u cloudflared -n 100 --no-pager
```

## 5) App service (Gunicorn) reminders

Your provided unit file (`complaintdesk.service`) expects:
- Code at `/opt/complaint_test`
- Venv at `/opt/complaint_test/.venv`
- Env file at `/opt/complaint_test/.env`

Enable it:

```bash
sudo cp complaintdesk.service /etc/systemd/system/complaintdesk.service
sudo systemctl daemon-reload
sudo systemctl enable --now complaintdesk
sudo systemctl status complaintdesk --no-pager
```

## 6) Port exposure model

- **Do not open inbound ports** on your router for the Flask/Gunicorn port.
- The app should listen on **localhost only** (as in the tunnel config `127.0.0.1:5050`).
- Cloudflare Tunnel provides the public HTTPS endpoint and forwards to localhost.

